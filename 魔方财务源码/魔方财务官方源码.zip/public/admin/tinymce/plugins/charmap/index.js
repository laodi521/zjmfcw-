// Exports the "charmap" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/charmap')
//   ES2015:
//     import 'tinymce/plugins/charmap'
require('./plugin.js');