window.global = 'https://w1.test.idcsmart.com'
window.directory = 'admin'
